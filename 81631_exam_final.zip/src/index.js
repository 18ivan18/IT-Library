import { App } from "./App";
import { bootstrap } from "./utils";

bootstrap(document.body, App);
