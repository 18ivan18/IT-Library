export const config = {
  app: {
    port: 3000,
  },
  api: {
    technology: "php",
    url: "http://localhost/api/",
  },
};
